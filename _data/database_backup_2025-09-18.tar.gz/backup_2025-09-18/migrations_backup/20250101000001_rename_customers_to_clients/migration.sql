-- Rename customers table to clients
ALTER TABLE "customers" RENAME TO "clients";
